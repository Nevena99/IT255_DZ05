export class Hotel{
  name: string;
  price: number;
  location: string;

  constructor(name: string, price: number, location: string){
    this.name = name;
    this.price = price;
    this.location = location;
  }




}
