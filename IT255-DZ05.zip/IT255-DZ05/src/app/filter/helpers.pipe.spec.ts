import { HelpersPipe } from './helpers.pipe';

describe('HelpersPipe', () => {
  it('create an instance', () => {
    const pipe = new HelpersPipe();
    expect(pipe).toBeTruthy();
  });
});
