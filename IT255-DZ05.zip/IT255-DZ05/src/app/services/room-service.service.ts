import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class RoomServiceService {

  constructor() { }

  getPrice(numberOfNights: number) {
    return numberOfNights * 5;
  }
}
